function jscontact(){
	$(document).ready(function(){
		var name=$('#name').val();
		var email=$('#email').val();
	    var msg=$('#message').val();
	    var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

		$.ajax({
			url:"Users/contact",
			method:"POST",
			data:{'name':name,email:email,'msg':msg},
			success:function(message){
				if(!isEmptyObject(message.error)){
				alert(message);
				$("#contact-msg").html(message.success);}
				else{
					$("#contact-msg").html("Invalid email");
				}
				}
				
			
		});
	});
}