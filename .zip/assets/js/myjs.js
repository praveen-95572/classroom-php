function mylogin(){
    alert("yes");
	$("html, body").animate({ scrollTop:50 }, 1000);
	setTimeout(function(){$('.content,footer').css("filter","blur(3px)");},1000 );
	$('#login').css({'display':'block'});
	//$('.content,footer').attr('disabled');
}
function loginhide(){
	$('#login').fadeOut(900);
	$('.content,footer').css("filter","blur(0)");
}

function sidebarClick(){
    alert("yes0");
    //$("#sidebar").css({"display":"block"});
}
 
$(document).ready(function(){ 

	$("#sidebar i").click(function(){
        alert("YES");
		$(this).next('#vid_table').slideToggle(900,"linear");
	});
/*
    $("#button_content").(function(){
        alert("yes");
        //$('#sidebar').css({'display':'block','z-index':'9999999'});
    });
*/
 	$("#login_form").submit(function(){
        dataString = $("#login_form").serialize();

        $.ajax({
            type: "POST",
            url: "<?php echo base_url()?>Users/login",
            data: dataString,
            //dataType: "json";
            beforeSend: function () {
                $(".error").html("Validating"); 
                $(".error").addClass("alert alert-primary");},
            success:function(data){
                var response=JSON.parse(data);
                alert(response.msg);
                if(response.status==1){
                setTimeout(function(){$(".error").html("Login Successful"); 
                        $(".error").addClass("alert alert-success");},1000);
                setTimeout(function(){$('#login').fadeOut(1000);
                        $('.content,footer').css("filter","blur(0)");},3000);
                }
                if(response.status==0){
                    $(".error").addClass("alert alert-danger");
                    $('.content,footer').css("filter","blur(0)");
                }
            }
            error:function(data){
                alert("YES");
            }

        });
         //$(".error").html(''); 
         return false;
               
    });


   $("#contact").submit(function(){
        var dataString=$('#contact').serialize();
        alert(dataString);
        $.ajax({
            type:'post',
            url:"<?php echo base_url('Users/contact');?>",
            data:dataString,
            beforeSend: function () {
                $(".error").html("Validating"); 
                $(".error").addClass("alert alert-primary");},
            success:function(data){
                setTimeout(function(){$(".error").html(data); 
                        $(".error").addClass("alert alert-success");},1000);
            }
        });
        return false;
    });

});