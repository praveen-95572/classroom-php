<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('userModel/crud','crud');
	}

	public function index()
	{
		$courses=$this->crud->get_courses();
		$this->load->view('Users/index',['courses'=>$courses]);
	}
	public function register(){
		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('email','Email','required|valid_email|is_unique[student.email]');
		$this->form_validation->set_rules('password','Password','required|min_length[10]');
		$this->form_validation->set_rules('mobile','Mobile no.','required|min_length[10]|max_length[10]');
		$this->form_validation->set_error_delimiters('<div class="error text-danger">','</div>');
		if($this->form_validation->run()){
		$post=$this->input->post();
		$this->crud->register($post);

		}
		else{
			return redirect('Users');
		}
	}

	public function courses($id){
		$courses=$this->crud->get_courses();
		$scourses=$this->crud->get_scourses($id);
		$this->load->view('Users/course',['scourses'=>$scourses,'courses'=>$courses]);
	}

	public function category($id,$vid){
		$id=$this->uri->segment(3);
		$vid=$this->uri->segment(4);
		echo "<script>alert('$vid');</script>";
		$courses=$this->crud->get_courses();
		$category=$this->crud->get_category($id);
		$scourses=$this->crud->get_subcourses($id);
		$video=$this->crud->get_video($vid='');
		$this->load->view('Users/category',['courses'=>$courses,'category'=>$category,'scourse'=>$scourses,'video'=>$video]); 	
	}

	public function contact(){
		$u_id='';
		if($this->session->userdata('id'))
			$u_id=$this->session->userdata('id');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('name','name','required');
        $this->form_validation->set_rules('msg','message','required|min_length[50]');
        if ($this->form_validation->run() == FALSE){
			$errors = validation_errors();
            echo $errors;
        }else{
        	echo "Response submitted";
		$array=$this->input->post();
		$this->crud->contact($array);	
		}
	}

	public function login(){
		$post=$this->input->post();
		$q=$this->crud->login($post);
		if($q){
			$this->session->set_userdata('login','Yes');
			$this->session->set_userdata("id",$q[0]->id);
			$this->session->set_userdata('name',$q[0]->name);
			die(json_encode(array('status'=>1,'msg'=>'success')));
		}
		else
			die(json_encode(array('status'=>0,'msg'=>'failed')));
	}
}
