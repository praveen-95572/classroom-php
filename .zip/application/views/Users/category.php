<?php include 'header.php'; ?>
   

   <section class="content section" id="top"  data-section="section1">
    <div class="container-fluid">
      <div id="button_content">Contents<button onclick="sidebarClick()"><i class="fa fa-table"></i></button></div>
      <br>
      <div class="row">
      <div class="col-md-4 col-lg-4 container">
        <div id="sidebar">
          <h4>Introduction</h4> 
          <?php foreach ($category as $cat) {?>
            <h4><?=$cat->name ?><i class="fa fa-plus"></i></h4><div id="vid_table">
            <?php foreach ($video as $vid) {
              if($vid->sc_id==$cat->id){?>
              <a href="<?=site_url('Users/category/{$scourse[0]->id}/{$vid->id}') ?>"><?=$vid->name; ?></a>
            <?php }} echo "</div>";}?>  
        </div>  
      </div>  
      <div class="view_content col-md-8 col-lg-8">
        <h2><?php echo($scourse[0]->name); ?></h2>
        <?php
          if($video!=0) { $src=$video[0]->link;  
                          $code=$video[0]->link; }
          else          {  $src=$scourse[0]->link;
                            $code=0;}
          $src.="?autoplay=1&mute=0";
        ?>
        <div class="video">
          <iframe width="100%" height="400"
              src="<?php // echo $src; ?>" alt="Loading">
          </iframe></div>
        <div class="code">
          <iframe src="https://www.tutorialrepublic.com/html-tutorial/html-iframes.php" style="border: 2px solid black;" name="myframe" width="100%" height="800"></iframe>
          <a href="" target="myframe">Open Src code web</a>
        </div>
      </div></div>
    </div>
  </section>
  

  
  
<?php include 'footer.php'; ?>

<script type="text/javascript">
  $(document).ready(function(){
  $("#sidebar i").hover(function(){
    alert('yes');
  //$x=$(this).next('#vid_table');
  //$x.slideToggle(900,"linear");
});
  $("#vid_table").hide();

});
</script>