<?php

class crud extends CI_Model
{ 
	public function login($post){
		$username=$post['username'];
		$password=md5($post['password']);
		$q=$this->db->where(['username'=>$username,'password'=>$password])
					->get('admin_users');

		return $q->num_rows();
	}
	public function get_courses(){
		$q=$this->db->where('status',1)
				 ->get('courses');
		return $q->result();
	}

	public function add_course($post){
		$q=$this->db->insert('courses',$post);
		return $q;
	}

	public function get_scourses(){
		$q=$this->db->where('status',1)
				 ->get('sub_courses');
		return $q->result();
	}

	public function add_sub_course($post){
		$q=$this->db->insert('sub_courses',$post);
		return $q;
	}

	public function get_category(){
		$q=$this->db->where('status',1)
				 ->get('category');
		return $q->result();
	}

	public function add_category($post){
		$q=$this->db->insert('category',$post);
		return $q;
	}

}

?>